#!/usr/bin/env bash
set -euo pipefail

REPO_URL="https://github.com/jurab/chatbot.git"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${SCRIPT_DIR}/chatbot"
SESSION_NAME="chatbot"

# clone repo if missing
if [ ! -d "${REPO_DIR}/.git" ]; then
    echo "[*] cloning repo into ${REPO_DIR}"
    git clone "${REPO_URL}" "${REPO_DIR}"
else
    echo "[*] repo already present at ${REPO_DIR}"
fi

cd "${REPO_DIR}"

# create venv if missing
if [ ! -d ".venv" ]; then
    echo "[*] creating venv"
    python3 -m venv .venv
fi

# activate venv
# shellcheck disable=SC1091
source .venv/bin/activate

# install requirements
if [ -f "requirements.txt" ]; then
    echo "[*] installing requirements"
    pip install -r requirements.txt
else
    echo "[!] requirements.txt missing, ty vole…"
fi

# ensure tmux exists
if ! command -v tmux >/dev/null 2>&1; then
    echo "tmux not found. install tmux first."
    exit 1
fi

# kill old session
if tmux has-session -t "${SESSION_NAME}" >/dev/null 2>&1; then
    tmux kill-session -t "${SESSION_NAME}"
fi

PROJECT_CMD="cd ${REPO_DIR} && source .venv/bin/activate"

# start session w/ frontend
tmux new-session -d -s "${SESSION_NAME}" \
    "${PROJECT_CMD} && python -m http.server 5500"

# split horizontally (side-by-side)
tmux split-window -h -t "${SESSION_NAME}" \
    "${PROJECT_CMD} && uvicorn main:app --reload"

tmux select-layout tiled >/dev/null 2>&1 || true

echo "[*] tmux session ${SESSION_NAME} started: left=frontend, right=backend"

tmux attach -t "${SESSION_NAME}"
