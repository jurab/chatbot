param(
    [string]$RepoUrl = "https://github.com/jurab/chatbot.git",
    [string]$RepoDir = "$PSScriptRoot\chatbot"
)

# clone if missing
if (!(Test-Path "$RepoDir\.git")) {
    Write-Host "[*] cloning repo to $RepoDir"
    git clone $RepoUrl $RepoDir
} else {
    Write-Host "[*] repo already exists"
}

Set-Location $RepoDir

# create venv if missing
if (!(Test-Path ".venv")) {
    Write-Host "[*] creating venv"
    python -m venv .venv
}

# activate venv
$venv = ".venv\Scripts\activate.ps1"
if (!(Test-Path $venv)) {
    Write-Host "venv activation script missing, kámo."
    exit 1
}

# install dependencies
if (Test-Path "requirements.txt") {
    Write-Host "[*] installing requirements"
    & powershell -NoExit "$venv; pip install -r requirements.txt"
} else {
    Write-Host "[!] requirements.txt missing lmao"
}

# start frontend in a new terminal
Start-Process pwsh -ArgumentList "-NoExit", "-Command", "`"$venv; python -m http.server 5500`""

# start backend in a new terminal
Start-Process pwsh -ArgumentList "-NoExit", "-Command", "`"$venv; uvicorn main:app --reload`""
